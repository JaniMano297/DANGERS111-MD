module.exports = {
  apps : [{
    name: "@`👑 𝐉𝐀𝐍𝐢 👑`-𝐌𝐃",
    script: "./server.js",
    watch: false,
    autorestart: true,
    max_memory_restart: '4G',
    env: {
      NODE_ENV: "production",
    }
  }]
};
