module.exports = {
    giphyApiKey: process.env.GIPHY_API_KEY || 'dc6zaTOxFJmzC',
    ownerNumber: process.env.OWNER_TELEGRAM || '@dangers111',
    botName: '`👑 𝐉𝐀𝐍𝐢 👑`-𝐌𝐃',
    ownerName: '`👑 𝐉𝐀𝐍𝐢 👑`'
};
